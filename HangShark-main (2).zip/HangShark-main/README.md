# Game Title and Description

Welcome to our game, HANGSHARK!
This is a simple and fun version of Hangman with an ocean-themed twist. You can choose from several categories: Fish, Sharks, Mammals, Shellfish, and Mystery. The Mystery category includes all types of oceanic animals from any of the other categories.

# Game Rules

The rules are simple!
Guess the hidden word one letter at a time. There is no time limit, but you only have six wrong guesses before the shark gets caught for dinner!

# Development Notes

We both worked together to develop the game, create the themes and categories, handle the coding and design, and ensure the user interface is simple and smooth.

The key features of our game include ocean-themed categories, animated shark graphics, themed colours and backgrounds, background music, and an exciting “Mystery” mode featuring various oceanic animals to give players a fun challenge.

The known issue is the delayed responsiveness of the shark stages when the player clicks on the wrong letter. This usually occurs during the first playthrough, but the responsiveness improves on subsequent attempts. 
